from pydantic import BaseModel

from pylon_identity.api.admin.schemas.action_schema import ActionPublic


class TaskSchema(BaseModel):
    name: str
    tag_name: str
    icon: str
    show_in_menu: str
    menu_title: str


class TaskUpdate(BaseModel):
    name: str
    tag_name: str
    icon: str
    show_in_menu: str
    menu_title: str


class TaskPublic(BaseModel):
    id: int
    name: str
    tag_name: str
    icon: str
    show_in_menu: str
    menu_title: str
    actions: list[ActionPublic]


class TaskList(BaseModel):
    tasks: list[TaskPublic]
