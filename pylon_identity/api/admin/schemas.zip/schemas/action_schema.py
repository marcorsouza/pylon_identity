from pydantic import BaseModel

from pylon_identity.api.admin.schemas.task_schema import TaskPublic


class ActionSchema(BaseModel):
    name: str
    task_id: int


class ActionUpdate(BaseModel):
    name: str
    task_id: int


class ActionPublic(BaseModel):
    id: int
    name: str
    task: TaskPublic


class ActionList(BaseModel):
    actions: list[ActionPublic]
